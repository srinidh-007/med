
import React from 'react'
import HomeStyle from './Home.module.css';

const Home = () => {
  return (
    <div>

    <div className={HomeStyle.home_wrap}>

    <header className={` header ${HomeStyle.header}`}>
      <div className={`container header__container ${HomeStyle.container} ${HomeStyle.header__container}`}>
    <div className={HomeStyle.header__logo}>
      <img className={HomeStyle.header__img} src="https://image.ibb.co/kcVou6/path3000.png" />
      <h1 className={HomeStyle.header__title}>Medi<span className={HomeStyle.header__light}>.co</span></h1></div>
         <button type="button" className={` navbar-toggle collapsed ${HomeStyle.navbar_toggle} ${HomeStyle.collapsed}`} data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                  <span className="sr-only">Toggle navigation</span>
                  <span className={` icon_bar ${HomeStyle.icon_bar}`}></span>
                  <span className={` icon_bar ${HomeStyle.icon_bar}`}></span>
                  <span className={` icon_bar ${HomeStyle.icon_bar}`}></span>
                </button>

      <div className={HomeStyle.header__menu}>
        <nav id="navbar" className={`${HomeStyle.header__nav} ${HomeStyle.collapse}`}>
          <ul className={HomeStyle.header__elenco}>
            <li className={HomeStyle.header__el}><a href="#" className={HomeStyle.header__link}>Home</a></li>
            <li className={HomeStyle.header__el}><a href="/about" className={HomeStyle.header__link}>About</a></li>
            <li className={HomeStyle.header__el}><a href="#" className={HomeStyle.header__link}>Specialized Areas</a></li>
            <li className={HomeStyle.header__el}><a href="#" className={HomeStyle.header__link}>Blog</a></li>
            <li className={HomeStyle.header__el}><a href="#contact" className={HomeStyle.header__link}>Contact us</a></li>
            <li className={`${HomeStyle.header__el} ${HomeStyle.header__el__blue}`}><a href="/login" className={`btn ${HomeStyle.btn} ${HomeStyle.btn__white}`}>Sign In →</a></li>
          </ul>
        </nav>
      </div>
        </div>
    </header>

    <div className={` sect sect__padding_top ${HomeStyle.sect} ${HomeStyle.sect__padding_top}`}>
      <div className={` container ${HomeStyle.container}`}>
        <div className={` row ${HomeStyle.row}`}>
          <div className="col-md-12">
        <div className={` site ${HomeStyle.site} `}>
          <h1 className={` site__title ${HomeStyle.site__title}`}>You are in safe hands</h1>
          <h2 className={` site__subtitle ${HomeStyle.site__subtitle}`}>Choose the experts in end to end surgical care</h2>
          <div className={` site__box_link ${HomeStyle.site__box_link}`}>
            <a className={`btn btn__width ${HomeStyle.btn} ${HomeStyle.btn__width}`} href="/signup">Sign Up</a>
            <a className={`btn btn__revert btn__width ${HomeStyle.btn} ${HomeStyle.btn__revert} ${HomeStyle.btn__width}`} href="#contact">Contact</a>
          </div>
          <img className={` site__img ${HomeStyle.site__img}`} src="" />
        </div>
        </div>
        </div>
      </div>
    </div>




    <section className={` section2 ${HomeStyle.section2}`}>
    <div className={` cards ${HomeStyle.cards}`}>
    <div className={` card ${HomeStyle.card}`}>
    <i className={` fa fa-medkit ${HomeStyle.fa} `}></i>
    <h1>Qualified Doctors</h1>
    <p>Lorem ipsum amet, consectetur adipiscing elit, sed do eiusmod tempor cididunt facilisis.</p>
    </div>
    <div className={` card ${HomeStyle.card}`}>
    <i className={` fa fa-certificate ${HomeStyle.fa} `}></i>
    <h1>Certified Services</h1>
    <p>Lorem ipsum amet, consectetur adipiscing elit, sed do eiusmod tempor cididunt facilisis.</p>
    </div>
    <div className={` card ${HomeStyle.card}`}>
    <i className={` fa fa-stethoscope ${HomeStyle.fa} `}></i>
    <h1>Advanced Equipment</h1>
    <p>Lorem ipsum amet, consectetur adipiscing elit, sed do eiusmod tempor cididunt facilisis.</p>
    </div>
    <div className={` card ${HomeStyle.card}`}>
    <i className={` fa fa-heartbeat ${HomeStyle.fa} `}></i>
    <h1>Emergency Service</h1>
    <p>Lorem ipsum amet, consectetur adipiscing elit, sed do eiusmod tempor cididunt facilisis.</p>
    </div>
    </div>
    </section>



    <main className={HomeStyle.service_container}>
      <article className={`${HomeStyle.service_card} ${HomeStyle.service_shadow}`}>
        <img className={HomeStyle.service_card_img} src="https://i.ibb.co/fkgFjgp/pexels-edward-jenner-4031824.jpg" alt="pexels-edward-jenner-4031824" border="0" />
        <h3 className={HomeStyle.service_card__title}>Instant Video Consultation</h3>
        <p className={HomeStyle.service_card__paragraph}>Connect within 60 seconds</p>
      </article>
      <article className={`${HomeStyle.service_card} ${HomeStyle.service_shadow}`}>
        <img className={HomeStyle.service_card_img} src="https://i.ibb.co/bKh4yKG/pexels-andrea-piacquadio-3881247.jpg" alt="pexels-edward-jenner-4031824" border="0" />
        <h3 className={HomeStyle.service_card__title}>Find Doctos Near You</h3>
        <p className={HomeStyle.service_card__paragraph}>Confirmed appointments</p>
      </article>
      <article className={`${HomeStyle.service_card} ${HomeStyle.service_shadow}`}>
        <img className={HomeStyle.service_card_img} src="https://i.ibb.co/Zxnt4sY/pexels-ivan-samkov-4989175.jpg" alt="pexels-edward-jenner-4031824" border="0" />
        <h3 className={HomeStyle.service_card__title}>Medicines</h3>
        <p className={HomeStyle.service_card__paragraph}>Essentials at your door step</p>
      </article>
      <article className={`${HomeStyle.service_card} ${HomeStyle.service_shadow}`}>
        <img className={HomeStyle.service_card_img} src="https://i.ibb.co/0YQznck/pexels-pixabay-356040.jpg" alt="pexels-pixabay-356040" alt="pexels-edward-jenner-4031824" border="0" />
        <h3 className={HomeStyle.service_card__title}>Lab Tests</h3>
        <p className={HomeStyle.service_card__paragraph}>Sample pickup at your home</p>
      </article>
      <article className={`${HomeStyle.service_card} ${HomeStyle.service_shadow}`}>
        <img className={HomeStyle.service_card_img} src="https://i.ibb.co/phr3kBy/pexels-tima-miroshnichenko-5452201.jpg" alt="pexels-edward-jenner-4031824" border="0" />
        <h3 className={HomeStyle.service_card__title}>Surgeries</h3>
        <p className={HomeStyle.service_card__paragraph}>Safe and trusted surgery centers</p>
      </article>
    </main>



    <div id="contact" className={`${HomeStyle.sect} ${HomeStyle.sect__padding_bottom}`}>
      <div className={` container ${HomeStyle.container}`}>
        <div className={` row ${HomeStyle.row}`}>
         <h1 className={HomeStyle.row__title}>
        Contact Us </h1>
      <h2 className={HomeStyle.row__sub}>Feel free to ask any questions</h2>
        </div>
        <div className={`row ${HomeStyle.row} ${HomeStyle.row__margin}`}>
          <div className="col-md-1"></div>
          <div className="col-md-4">
            <div className={HomeStyle.contacts}>
              <a href="#" className={HomeStyle.contacts__link}><img src="https://image.ibb.co/kcVou6/path3000.png" />
                <h1 className={HomeStyle.contacts_title_ag}>Medi<span className={HomeStyle.contacts__light}>.co</span></h1></a>
              <p className={HomeStyle.contacts__address}>
                431 Broadway, Floor 1-2<br />
                New York NY 10013<br />
                United States
              </p>
              <p className={HomeStyle.contacts__info}>
                tel. <a href="#" className={HomeStyle.contacts__info_link}>+1 234 567 890</a>
              </p>
              <p className={HomeStyle.contacts__info}>
                m. <a href="#"className={HomeStyle.contacts__info_link}>info@medi.co</a>
              </p>
            </div>
          </div>
          <div className="col-md-6">
            <form id="contact" className={` form ${HomeStyle.form}`}>
               <div className={`form-group ${HomeStyle.form_group}`}>
                <input type="text" placeholder="Name*" className={`${HomeStyle.form__field} ${HomeStyle.form__text}`}></input>

              </div>

            <div className={`form-group ${HomeStyle.form_group}`}>
              <div className={HomeStyle.form__field__half}>
                <input type="text" placeholder="Email address*" className={`${HomeStyle.form__field} ${HomeStyle.form__text}`}></input>
              </div>
             <div className={HomeStyle.form__field__half}>
              <input type="text" placeholder="Phone number" className={`${HomeStyle.form__field} ${HomeStyle.form__text}`}></input>
        </div>
              </div>

              <div className={`form-group ${HomeStyle.form_group}`}>
                <textarea type="text" placeholder="Your messsage*" className={`${HomeStyle.form__field} ${HomeStyle.form__textarea}`}></textarea>
                <button className={`btn ${HomeStyle.btn} ${HomeStyle.btn__up} ${HomeStyle.btn__width}`} type="submit">Submit</button>
              </div>
            </form>
          </div>
    <div className="col-md-1"></div>
        </div>
      </div>
    </div>

    <div className={`${HomeStyle.sect} ${HomeStyle.sect__violet}`}>
      <img src="https://image.ibb.co/fWyVtb/path3762.png" className={HomeStyle.career_img} />
      <div className={`container ${HomeStyle.container}`}>
        <div className={`row ${HomeStyle.row}`}>
          <div className="col-md-12">
            <h1 className={HomeStyle.career_title}>Book an appointment for an in-clinic consultation!</h1>
            <h1 className={HomeStyle.career_sub}>Find experienced doctors across all specialties</h1>
            <a href="#" className={` btn btn__white btn__width ${HomeStyle.btn} ${HomeStyle.btn__white} ${HomeStyle.btn__width}`}>Know More</a>
          </div>
        </div>
      </div>

    </div>

    <footer className={HomeStyle.footer}>
      <div className={`container ${HomeStyle.container}`}>
        <div className={`row ${HomeStyle.row}`}>
          <div className="col-md-2 col-xs-6">
           <img className={HomeStyle.footer__img} src="https://image.ibb.co/kcVou6/path3000.png" />
           <h1 className={HomeStyle.footer__title}>Medi<span className={HomeStyle.footer__light}>.co</span></h1></div>
          <div className="col-md-10 col-xs-6">
            <div className={HomeStyle.footer__social}>
              <a href="#" className={HomeStyle.footer__social_l}>
                <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTguMS4xLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDYxMiA2MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDYxMiA2MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KPGc+Cgk8Zz4KCQk8cGF0aCBkPSJNNjEyLDExNi4yNThjLTIyLjUyNSw5Ljk4MS00Ni42OTQsMTYuNzUtNzIuMDg4LDE5Ljc3MmMyNS45MjktMTUuNTI3LDQ1Ljc3Ny00MC4xNTUsNTUuMTg0LTY5LjQxMSAgICBjLTI0LjMyMiwxNC4zNzktNTEuMTY5LDI0LjgyLTc5Ljc3NSwzMC40OGMtMjIuOTA3LTI0LjQzNy01NS40OS0zOS42NTgtOTEuNjMtMzkuNjU4Yy02OS4zMzQsMC0xMjUuNTUxLDU2LjIxNy0xMjUuNTUxLDEyNS41MTMgICAgYzAsOS44MjgsMS4xMDksMTkuNDI3LDMuMjUxLDI4LjYwNkMxOTcuMDY1LDIwNi4zMiwxMDQuNTU2LDE1Ni4zMzcsNDIuNjQxLDgwLjM4NmMtMTAuODIzLDE4LjUxLTE2Ljk4LDQwLjA3OC0xNi45OCw2My4xMDEgICAgYzAsNDMuNTU5LDIyLjE4MSw4MS45OTMsNTUuODM1LDEwNC40NzljLTIwLjU3NS0wLjY4OC0zOS45MjYtNi4zNDgtNTYuODY3LTE1Ljc1NnYxLjU2OGMwLDYwLjgwNiw0My4yOTEsMTExLjU1NCwxMDAuNjkzLDEyMy4xMDQgICAgYy0xMC41MTcsMi44My0yMS42MDcsNC4zOTgtMzMuMDgsNC4zOThjLTguMTA3LDAtMTUuOTQ3LTAuODAzLTIzLjYzNC0yLjMzM2MxNS45ODUsNDkuOTA3LDYyLjMzNiw4Ni4xOTksMTE3LjI1Myw4Ny4xOTQgICAgYy00Mi45NDcsMzMuNjU0LTk3LjA5OSw1My42NTUtMTU1LjkxNiw1My42NTVjLTEwLjEzNCwwLTIwLjExNi0wLjYxMi0yOS45NDQtMS43MjFjNTUuNTY3LDM1LjY4MSwxMjEuNTM2LDU2LjQ4NSwxOTIuNDM4LDU2LjQ4NSAgICBjMjMwLjk0OCwwLDM1Ny4xODgtMTkxLjI5MSwzNTcuMTg4LTM1Ny4xODhsLTAuNDIxLTE2LjI1M0M1NzMuODcyLDE2My41MjYsNTk1LjIxMSwxNDEuNDIyLDYxMiwxMTYuMjU4eiIgZmlsbD0iIzcyOTNiMyIvPgoJPC9nPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=" />
              </a>
              <a href="#" className={HomeStyle.footer__social_l}>
                <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDk2LjEyNCA5Ni4xMjMiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDk2LjEyNCA5Ni4xMjM7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8cGF0aCBkPSJNNzIuMDg5LDAuMDJMNTkuNjI0LDBDNDUuNjIsMCwzNi41Nyw5LjI4NSwzNi41NywyMy42NTZ2MTAuOTA3SDI0LjAzN2MtMS4wODMsMC0xLjk2LDAuODc4LTEuOTYsMS45NjF2MTUuODAzICAgYzAsMS4wODMsMC44NzgsMS45NiwxLjk2LDEuOTZoMTIuNTMzdjM5Ljg3NmMwLDEuMDgzLDAuODc3LDEuOTYsMS45NiwxLjk2aDE2LjM1MmMxLjA4MywwLDEuOTYtMC44NzgsMS45Ni0xLjk2VjU0LjI4N2gxNC42NTQgICBjMS4wODMsMCwxLjk2LTAuODc3LDEuOTYtMS45NmwwLjAwNi0xNS44MDNjMC0wLjUyLTAuMjA3LTEuMDE4LTAuNTc0LTEuMzg2Yy0wLjM2Ny0wLjM2OC0wLjg2Ny0wLjU3NS0xLjM4Ny0wLjU3NUg1Ni44NDJ2LTkuMjQ2ICAgYzAtNC40NDQsMS4wNTktNi43LDYuODQ4LTYuN2w4LjM5Ny0wLjAwM2MxLjA4MiwwLDEuOTU5LTAuODc4LDEuOTU5LTEuOTZWMS45OEM3NC4wNDYsMC44OTksNzMuMTcsMC4wMjIsNzIuMDg5LDAuMDJ6IiBmaWxsPSIjNzI5M2IzIi8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==" />
              </a>

               <a href="#" className={HomeStyle.footer__social_l}>
              <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDQzOC41MzMgNDM4LjUzMyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDM4LjUzMyA0MzguNTMzOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxnPgoJPHBhdGggZD0iTTQwOS4xMzMsMTA5LjIwM2MtMTkuNjA4LTMzLjU5Mi00Ni4yMDUtNjAuMTg5LTc5Ljc5OC03OS43OTZDMjk1LjczNiw5LjgwMSwyNTkuMDU4LDAsMjE5LjI3MywwICAgYy0zOS43ODEsMC03Ni40Nyw5LjgwMS0xMTAuMDYzLDI5LjQwN2MtMzMuNTk1LDE5LjYwNC02MC4xOTIsNDYuMjAxLTc5LjgsNzkuNzk2QzkuODAxLDE0Mi44LDAsMTc5LjQ4OSwwLDIxOS4yNjcgICBjMCwzOS43OCw5LjgwNCw3Ni40NjMsMjkuNDA3LDExMC4wNjJjMTkuNjA3LDMzLjU5Miw0Ni4yMDQsNjAuMTg5LDc5Ljc5OSw3OS43OThjMzMuNTk3LDE5LjYwNSw3MC4yODMsMjkuNDA3LDExMC4wNjMsMjkuNDA3ICAgczc2LjQ3LTkuODAyLDExMC4wNjUtMjkuNDA3YzMzLjU5My0xOS42MDIsNjAuMTg5LTQ2LjIwNiw3OS43OTUtNzkuNzk4YzE5LjYwMy0zMy41OTYsMjkuNDAzLTcwLjI4NCwyOS40MDMtMTEwLjA2MiAgIEM0MzguNTMzLDE3OS40ODUsNDI4LjczMiwxNDIuNzk1LDQwOS4xMzMsMTA5LjIwM3ogTTIxOS4yNywzMS45NzdjNDcuMjAxLDAsODguNDEsMTUuNjA3LDEyMy42MjEsNDYuODJsLTMuNTY5LDQuOTkzICAgYy0xLjQyNywyLjAwMi00Ljk5Niw1Ljg1Mi0xMC43MDQsMTEuNTY1Yy01LjcwOSw1LjcwOC0xMS45NDMsMTEuMTM2LTE4LjY5OSwxNi4yNzRjLTYuNzYyLDUuMTQtMTUuOTQsMTAuOTkyLTI3LjU1NSwxNy41NTkgICBjLTExLjYxMSw2LjU2Ny0yMy45ODIsMTIuMzI4LTM3LjExNywxNy4yNzZjLTIxLjg4Ny00MC4zNTUtNDUuMjk2LTc2LjcwOS03MC4yMzEtMTA5LjA2NCAgIEMxOTAuMDU1LDMzLjc4NCwyMDQuODA1LDMxLjk3NywyMTkuMjcsMzEuOTc3eiBNNzIuNTI0LDEwMy4wNmMxOC4yNzEtMjMuMDI2LDQwLjUzNy00MC43Myw2Ni44MDYtNTMuMSAgIGMyMy42MDEsMzEuNDA1LDQ2LjgyLDY3LjM4MSw2OS42NjIsMTA3LjkyMWMtNTcuODYyLDE1LjIyNy0xMTUuNTMyLDIyLjg0MS0xNzMuMDE0LDIyLjgzOCAgIEM0Mi4wNzIsMTUxLjk4LDU0LjI1MywxMjYuMDkxLDcyLjUyNCwxMDMuMDZ6IE00NC41NCwyODYuNzk0Yy04LjM3Ni0yMS40MTItMTIuNTYzLTQzLjkyMy0xMi41NjMtNjcuNTI3ICAgYzAtMi42NjYsMC4wOTgtNC42NjUsMC4yODYtNS45OTZjNjguOTA1LDAsMTMyLjk1NS04Ljg0OCwxOTIuMTQ5LTI2LjU1M2M2LjA5MiwxMS44LDExLjEzNiwyMi4zNjQsMTUuMTMzLDMxLjY5MyAgIGMtMC43NzEsMC4zOC0xLjk5OSwwLjgwNi0zLjcxMywxLjI4M2MtMS43MTksMC40NzYtMi45NTMsMC44MDYtMy43MjEsMC45OTlsLTEwLjU2MSwzLjcxMSAgIGMtNy4yMzYsMi42NjYtMTYuNzA4LDcuMjM1LTI4LjQwOSwxMy43MDNjLTExLjcwNCw2LjQ3OC0yNC4xMjMsMTQuMTgyLTM3LjI1NywyMy4xM2MtMTMuMTM0LDguOTQ5LTI2LjY5NiwyMC43OTctNDAuNjg0LDM1LjU1MyAgIGMtMTMuOTksMTQuNzUtMjUuNzQzLDMwLjU5MS0zNS4yNiw0Ny41M0M2NC43MTMsMzI3LjM4MSw1Mi45MTQsMzA4LjIsNDQuNTQsMjg2Ljc5NHogTTIxOS4yNyw0MDYuNTYgICBjLTQ0LjU0LDAtODQuMzItMTQuMjc3LTExOS4zNDMtNDIuODI1bDQuMjgzLDMuMTQyYzYuNjYxLTE0LjY2LDE2LjQ2Mi0yOC43NDYsMjkuNDA4LTQyLjI1NyAgIGMxMi45NDQtMTMuNTExLDI1LjQxLTI0LjQxMywzNy40MDEtMzIuNjk1YzExLjk5MS04LjI3NCwyNS4wMjgtMTYuMDc3LDM5LjExNS0yMy40MTRjMTQuMDg0LTcuMzIzLDIzLjY5MS0xMS45OTEsMjguODM1LTEzLjk4MyAgIGM1LjE0LTEuOTk4LDkuMjMzLTMuNTcyLDEyLjI3OC00LjcxNmwwLjU2OC0wLjI4N2gwLjU3NWMxOC42NDcsNDguOTE2LDMxLjk3Nyw5Ni4zMTMsMzkuOTY4LDE0Mi4xODQgICBDMjY4Ljc1Niw0MDEuNjExLDI0NC4zOTcsNDA2LjU1NywyMTkuMjcsNDA2LjU2eiBNMzc2Ljg3NiwzMjAuNDc5Yy0xNC4wODYsMjEuNzk2LTMxLjY5NiwzOS44MzQtNTIuODE3LDU0LjEwNCAgIGMtNy44MS00My43NzYtMTkuOTg1LTg4LjQxNS0zNi41NDktMTMzLjkwMmMzNy44NzctNS45MDcsNzYuOC0zLjE0MiwxMTYuNzcxLDguMjc0ICAgQzQwMC4wOTIsMjc0Ljg0MSwzOTAuOTU1LDI5OC42ODcsMzc2Ljg3NiwzMjAuNDc5eiBNNDAzLjcwNiwyMTYuNjk4Yy0xLjkwMy0wLjM3OC00LjI4NS0wLjgxLTcuMTM5LTEuMjgzICAgYy0yLjg1NC0wLjQ3My02LjMzMS0xLjA0Ny0xMC40MjQtMS43MTNjLTQuMDg3LTAuNjY2LTguNjYyLTEuMjgzLTEzLjcwMi0xLjg1NWMtNS4wNDUtMC41NzEtMTAuNDIxLTEuMDkzLTE2LjEzNi0xLjU2OSAgIGMtNS43MDgtMC40NzgtMTEuOC0wLjg1NS0xOC4yNjgtMS4xNDNjLTYuNDc5LTAuMjg0LTEzLjA0Mi0wLjQyOC0xOS43MDUtMC40MjhjLTYuNjU2LDAtMTMuNjU3LDAuMTkzLTIwLjk4MSwwLjU3MSAgIGMtNy4zMjYsMC4zNzUtMTQuNDE0LDEuMDQ5LTIxLjI2NSwxLjk5OWMtMC41NzUtMC45NTMtMS4yODctMi41MjQtMi4xNDMtNC43MTRjLTAuODU1LTIuMTg3LTEuNDc5LTMuODU1LTEuODQ4LTQuOTk3ICAgYy0zLjYyMS03Ljk5NC03LjgxLTE3LjAzNi0xMi41NzMtMjcuMTIxYzEzLjEzNC01LjMzMywyNS42NTItMTEuNDY5LDM3LjU1NS0xOC40MThjMTEuODkyLTYuOTQ5LDIxLjQwMi0xMy4xMzEsMjguNTQ0LTE4LjU1NSAgIGM3LjEzOS01LjQzLDEzLjg5NS0xMS4xODgsMjAuMjctMTcuMjc3YzYuMzc5LTYuMDksMTAuNTEzLTEwLjMyMywxMi40MjMtMTIuNzAzYzEuOTA2LTIuMzg0LDMuNzEzLTQuNzE0LDUuNDI0LTYuOTk1bDAuMjg3LTAuMjg4ICAgYzI3Ljc4OCwzMy44OCw0MS45NzQsNzIuODk3LDQyLjUzOCwxMTcuMDU5TDQwMy43MDYsMjE2LjY5OHoiIGZpbGw9IiM3MjkzYjMiLz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K" />
              </a>

              <a href="" className={HomeStyle.footer__social_l}>
                <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDQzMC4xMTcgNDMwLjExNyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDMwLjExNyA0MzAuMTE3OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxnPgoJPHBhdGggaWQ9IkxpbmtlZEluIiBkPSJNNDMwLjExNywyNjEuNTQzVjQyMC41NmgtOTIuMTg4VjI3Mi4xOTNjMC0zNy4yNzEtMTMuMzM0LTYyLjcwNy00Ni43MDMtNjIuNzA3ICAgYy0yNS40NzMsMC00MC42MzIsMTcuMTQyLTQ3LjMwMSwzMy43MjRjLTIuNDMyLDUuOTI4LTMuMDU4LDE0LjE3OS0zLjA1OCwyMi40NzdWNDIwLjU2aC05Mi4yMTljMCwwLDEuMjQyLTI1MS4yODUsMC0yNzcuMzJoOTIuMjEgICB2MzkuMzA5Yy0wLjE4NywwLjI5NC0wLjQzLDAuNjExLTAuNjA2LDAuODk2aDAuNjA2di0wLjg5NmMxMi4yNTEtMTguODY5LDM0LjEzLTQ1LjgyNCw4My4xMDItNDUuODI0ICAgQzM4NC42MzMsMTM2LjcyNCw0MzAuMTE3LDE3Ni4zNjEsNDMwLjExNywyNjEuNTQzeiBNNTIuMTgzLDkuNTU4QzIwLjYzNSw5LjU1OCwwLDMwLjI1MSwwLDU3LjQ2MyAgIGMwLDI2LjYxOSwyMC4wMzgsNDcuOTQsNTAuOTU5LDQ3Ljk0aDAuNjE2YzMyLjE1OSwwLDUyLjE1OS0yMS4zMTcsNTIuMTU5LTQ3Ljk0QzEwMy4xMjgsMzAuMjUxLDgzLjczNCw5LjU1OCw1Mi4xODMsOS41NTh6ICAgIE01LjQ3Nyw0MjAuNTZoOTIuMTg0di0yNzcuMzJINS40NzdWNDIwLjU2eiIgZmlsbD0iIzcyOTNiMyIvPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script><script  src="./script.js"></script>

    </div>

    </div>
  );
}

export default Home;
